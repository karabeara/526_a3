/* Include file for the R3 light class */



/* Initialization functions */

int R3InitLight();
void R3StopLight();



/* Class definition */

class R3Light {
    public:
      // Constructor functions
      R3Light(const char *name = NULL);
      R3Light(const R3Light& light, const char *name = NULL);
      R3Light(const RNRgb& color, RNScalar intensity = 1.0, RNBoolean active = TRUE, const char *name = NULL);
      virtual ~R3Light(void);

      // Property functions/operations
      R3Scene        *Scene(void) const;
      int             SceneIndex(void) const;
      const char     *Name(void) const;
      const RNBoolean IsActive(void) const;
      const RNScalar  Intensity(void) const;
      const RNRgb    &Color(void) const;

      // Manipulation functions/operations
      virtual void SetName(const char *name);
      virtual void SetActive(RNBoolean active);
      virtual void SetIntensity(RNScalar intensity);
      virtual void SetColor(const RNRgb& color);

      // Reflection evaluation functions
      virtual RNRgb Reflection(const R3Brdf& brdf, const R3Point& eye, 
                               const R3Point& point, const R3Vector& normal) const = 0;
      virtual RNRgb DiffuseReflection(const R3Brdf& brdf, 
                                      const R3Point& point, const R3Vector& normal) const = 0;
      virtual RNRgb SpecularReflection(const R3Brdf& brdf, const R3Point& eye, 
	                                     const R3Point& point, const R3Vector& normal) const = 0;

      // Get ray from light source to given point
      virtual const R3Ray LightToPointRay(R3Point point) const;

      // Give a randomly sampled ray from this light
      virtual const R3Ray RandomlySampledRay(void) const;

      // Give the power of a surface photon given the distance from the light source
      virtual const RNRgb PowerGivenDistance(R3Point reference_point, R3Vector normal) const;
      
      // Draw functions/operations
      virtual void Draw(int i) const = 0;

      // Class type definitions
      RN_CLASS_TYPE_DECLARATIONS(R3Light);

    private:
      friend class R3Scene;
      R3Scene     *scene;
      int          scene_index;
      char        *name;
      RNBoolean    active;
      RNScalar     intensity;
      RNRgb        color;
      int          id;
};



/* Public variables */

extern RNScalar R3ambient_light_intensity;
extern RNRgb R3ambient_light_color;


/* Inline functions */

inline R3Scene *R3Light::
Scene(void) const
{
  // Return scene 
  return scene;
}



inline int R3Light::
SceneIndex(void) const
{
  // Return index of light in scene (can be used with scene->Light(xxx))
  return scene_index;
}



inline const char *R3Light::
Name(void) const
{
    // Return name
    return name;
}



inline const RNBoolean R3Light::
IsActive(void) const
{
    // Return status
    return active;
}



inline const RNScalar R3Light::
Intensity(void) const
{
    // Return intensity 
    return intensity;
}



inline const RNRgb& R3Light::
Color(void) const
{
    // Return color 
    return color;
}



